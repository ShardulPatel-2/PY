import turtle
screen = turtle.Screen()




board = turtle.Turtle()

#Triangle
board.forward(100)
board.left(120)
board.forward(100)
board.left(120)
board.forward(100)
board.left(120)

#Square
board.left(90)
board.forward(100)
board.left(90)
board.forward(100)
board.left(90)
board.forward(100)
board.left(90)
board.forward(100)
